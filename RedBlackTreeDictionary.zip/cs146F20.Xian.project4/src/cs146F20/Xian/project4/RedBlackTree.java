package cs146F20.Xian.project4;

public class RedBlackTree<Key extends Comparable<Key>> {
	private static RedBlackTree.Node<String> root;

	public static class Node<Key extends Comparable<Key>> { // changed to static

		Key key;
		Node<String> parent;
		Node<String> leftChild;
		Node<String> rightChild;
		boolean isRed;
		int color;

		public Node(Key data) {
			this.key = data;
			leftChild = null;
			rightChild = null;
		}

		public int compareTo(Node<Key> n) { // this < that <0
			return key.compareTo(n.key); // this > that >0
		}

		public boolean isLeaf() {
			if (this.equals(root) && this.leftChild == null && this.rightChild == null)
				return true;
			if (this.equals(root))
				return false;
			if (this.leftChild == null && this.rightChild == null) {
				return true;
			}
			return false;
		}
	}

	public boolean isLeaf(RedBlackTree.Node<String> n) {
		if (n.equals(root) && n.leftChild == null && n.rightChild == null)
			return true;
		if (n.equals(root))
			return false;
		if (n.leftChild == null && n.rightChild == null) {
			return true;
		}
		return false;
	}

	public interface Visitor<Key extends Comparable<Key>> {
		/**
		 * This method is called at each node.
		 * 
		 * @param n the visited node
		 */
		void visit(Node<Key> n);
	}

	public void visit(Node<Key> n) {
		System.out.println(n.key);
	}

	public void printTree() { // preorder: visit, go left, go right
		RedBlackTree.Node<String> currentNode = root;
		printTree(currentNode);
	}

	public void printTree(RedBlackTree.Node<String> node) {
		System.out.print(node.key);
		if (node.isLeaf()) {
			return;
		}
		printTree(node.leftChild);
		printTree(node.rightChild);
	}

	// ***Filled by Benjamin X***
	// Place a new node in the RB tree with data the parameter and color it red.
	// If insert it at root, color it black instead.
	public void addNode(String data) {

		Node<String> n = new Node<String>(data);
		n.color = 0;
		n.isRed = true;
		Node<String> newNodePosition = root;
		Node<String> newNodeParent = null;

		// If the tree is empty
		if (root == null) {
			root = n;
			root.color = 1;
			root.isRed = false;
			return;
		}

		// "newNodePosition" will move on to find the right position for n
		// "newNodeParent" will find which is n's parent
		while (newNodePosition != null) {
			newNodeParent = newNodePosition;
			if (n.key.compareTo(newNodePosition.key) < 0) {
				newNodePosition = newNodePosition.leftChild;
			} else {
				newNodePosition = newNodePosition.rightChild;
			}
		}

		// Position found, make "newNodeParent" the parent of n
		n.parent = newNodeParent;

		// Determine whether n is left child of parentOfN or right child
		if (n.key.compareTo(newNodeParent.key) < 0) {
			newNodeParent.leftChild = n;
		} else {
			newNodeParent.rightChild = n;
		}
		return;

	}

	public void insert(String data) {
		addNode(data);
		// Added by Benjamin X, fix the RB tree after each insertion
		fixTree(lookup(data));
	}

	// ***Filled by Benjamin X***
	public RedBlackTree.Node<String> lookup(String k) {

		Node<String> current = root;

		if (root.key.compareTo(k) == 0) {

			return root;
		}

		while (!isLeaf(current)) {
			if (k.compareTo(current.key) < 0) {
				current = current.leftChild;
				if (current.key.compareTo(k) == 0) {
					// System.out.println("Looking at " + current.key);
					return current;
				}
			} else {
				current = current.rightChild;
				if (current.key.compareTo(k) == 0) {
					// System.out.println("Looking at " + current.key);
					return current;
				}
			}
		}
		// If k not found
		return null;
	}

	// ***Filled by Benjamin X***
	// Get n's sibling
	public RedBlackTree.Node<String> getSibling(RedBlackTree.Node<String> n) {
		if (n == n.parent.leftChild) {
			return n.parent.rightChild;
		} else {
			return n.parent.leftChild;
		}
	}

	// ***Filled by Benjamin X***
	// Get n's aunt
	public RedBlackTree.Node<String> getAunt(RedBlackTree.Node<String> n) {
		if (n.parent == n.parent.parent.leftChild) {
			return n.parent.parent.rightChild;
		} else {
			return n.parent.parent.leftChild;
		}
	}

	// ***Filled by Benjamin X***
	// Get n's grandparent
	public RedBlackTree.Node<String> getGrandparent(RedBlackTree.Node<String> n) {
		return n.parent.parent;
	}

	// ***Filled by Benjamin X***
	// Perform a left rotate at n
	public void rotateLeft(RedBlackTree.Node<String> n) {
		Node<String> m = n.rightChild;
		n.rightChild = m.leftChild;
		if (m.leftChild != null) {
			m.leftChild.parent = n;
		}
		m.parent = n.parent;

		// if n is the root, make m the new root
		if (n.parent == null) {
			RedBlackTree.root = m;
		}
		// If n is a right child, make m the new right child for n's parent
		else if (n == n.parent.rightChild) {
			n.parent.rightChild = m;
		}
		// If n is a left child, make m the new left child for n's parent
		else {
			n.parent.leftChild = m;
		}
		m.leftChild = n;
		n.parent = m;
	}

	// ***Filled by Benjamin X***
	// Perform a right rotate at n
	public void rotateRight(RedBlackTree.Node<String> n) {
		Node<String> m = n.leftChild;
		n.leftChild = m.rightChild;
		if (m.rightChild != null) {
			m.rightChild.parent = n;
		}
		m.parent = n.parent;
		// if n is the root, make m the new root
		if (n.parent == null) {
			RedBlackTree.root = m;
		}
		// If n is a right child, make n the new right child for n's parent
		else if (n == n.parent.rightChild) {
			n.parent.rightChild = m;
		}
		// If n is a left child, make n the new left child for n's parent
		else {
			n.parent.leftChild = m;
		}
		m.rightChild = n;
		n.parent = m;
	}

	// ***Filled by Benjamin X***
	// Fix RB tree after an insertion
	public void fixTree(RedBlackTree.Node<String> n) {

		while (n != root) {
			// If n's parent is black, no need to fix
			if (n.parent.color == 1) {
				return;
			}

			// If n's parent color is red, do the following
			if (n.parent.color == 0) {
				// If n's aunt is red, do the following
				if (getAunt(n) != null && getAunt(n).color == 0) {

					n.parent.color = 1;
					getAunt(n).color = 1;
					if (n.parent.parent != root) {
						n.parent.parent.color = 0;
					}

					n = n.parent.parent;

					continue;
				}

				// If n's aunt is black or does not exist, do the following
				else if (getAunt(n) == null || getAunt(n).color == 1) {

					// LL case
					if (n.parent == n.parent.parent.leftChild && n == n.parent.leftChild) {
						rotateRight(n.parent.parent);
						n.parent.color = 1;
						getSibling(n).color = 0;
						return;
					}

					// LR case
					if (n.parent == n.parent.parent.leftChild && n == n.parent.rightChild) {
						rotateLeft(n.parent);
						rotateRight(n.parent);
						n.parent.color = 1;
						getSibling(n).color = 0;
						return;
					}

					// RR case
					if (n.parent == n.parent.parent.rightChild && n == n.parent.rightChild) {
						rotateLeft(n.parent.parent);
						n.parent.color = 1;
						getSibling(n).color = 0;
						return;
					}

					// RL case
					if (n.parent == n.parent.parent.rightChild && n == n.parent.leftChild) {
						rotateRight(n.parent);
						rotateLeft(n.parent);
						n.parent.color = 1;
						getSibling(n).color = 0;
						return;
					}
				}

			}
		}

	}

	public boolean isEmpty(RedBlackTree.Node<String> n) {
		if (n.key == null) {
			return true;
		}
		return false;
	}

	public boolean isLeftChild(RedBlackTree.Node<String> parent, RedBlackTree.Node<String> child) {
		if (child.compareTo(parent) < 0) {// child is less than parent
			return true;
		}
		return false;
	}

	public void preOrderVisit(Visitor<String> v) {
		preOrderVisit(root, v);
	}

	private static void preOrderVisit(RedBlackTree.Node<String> n, Visitor<String> v) {
		if (n == null) {
			return;
		}
		v.visit(n);
		preOrderVisit(n.leftChild, v);
		preOrderVisit(n.rightChild, v);
	}
}